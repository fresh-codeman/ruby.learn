#!/bin/bash

bundle install
rake default sample_input/input1.txt