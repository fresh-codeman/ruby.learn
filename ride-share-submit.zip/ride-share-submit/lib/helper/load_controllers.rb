Dir[File.join(__dir__, '../controller/*.rb')].each { |file| require file }
